# O Inferno Verde — O Preço da Expedição

**O Inferno Verde** é um jogo de mesa sobre exploração, sobrevivência, desgaste e escolhas difíceis durante expedições que deixam assentamentos costeiros e avançam por uma vasta terra tropical fictícia.

O cenário é inspirado na cultura material, na tecnologia e na natureza das expedições dos séculos XV e XVI, especialmente nas Américas desse período, mas **não se passa nas Américas históricas**. Povos, reinos, rios, territórios e acontecimentos pertencem ao próprio cenário.

A floresta, a distância, a fome, a sede, as doenças, os ferimentos, a perda de equipamento, a Bagagem limitada e o medo do Desconhecido são pressões centrais. O Desconhecido permanece raro, ambíguo e incompreendido: um acontecimento pode ser superstição, fraude, delírio, fenômeno natural, interpretação religiosa ou algo para o qual ninguém possui explicação satisfatória.

---

## Como usar este projeto

Este `README.md` é a porta de entrada para o projeto. Ele resume a organização dos sources e explica como disparar os pipelines de produção.

**Ele não substitui os sources canônicos.** Em qualquer conflito, use sempre a versão mais recente do arquivo responsável pela regra em questão.

A regra operacional mais importante é:

> **Use sempre o arquivo de maior versão disponível de cada source.**

Arquivos antigos permanecem como histórico e não devem prevalecer sobre a versão mais recente.

---

## Sources principais

Versões vigentes no momento desta atualização:

| Source | Versão | Responsabilidade |
|---|---:|---|
| `Regras.v29.txt` | 29 | Sistema de jogo, listas canônicas, Ocupações, Aptidões, Pertences, Provações, ameaças e Relíquias |
| `Cenario.v12.txt` | 12 | Mundo, atmosfera, coerência histórica e tecnológica, lugares, perigos e Desconhecido |
| `Relatos.v7.txt` | 7 | Mini-contos, acontecimentos, vozes e atmosfera narrativa |
| `Images.v59.txt` | 59 | Como representar visualmente VINHETA, CENA, CARD e FOLHA |
| `Render.v8.txt` | 8 | PREVIEW, FINAL RASTER, resolução, montagem, validação técnica e entrega |
| `Livro.v2.txt` | 2 | Tipografia e apresentação editorial do livro, PDF e site |
| `Pipelines.v9.txt` | 9 | Sequências operacionais disparadas por `RODE:` |
| `Diretivas.v2.txt` | 2 | Regras internas de versionamento e uso dos sources |
| `Itch.v2.txt` | 2 | Regras específicas para arquivos destinados ao itch.io |

### Hierarquia por responsabilidade

- **Regras** determina o conteúdo mecânico e as listas canônicas.
- **Cenario** determina o que existe no mundo e o que é coerente nele.
- **Relatos** determina acontecimentos e atmosfera quando a arte parte de um relato.
- **Images** determina como o conteúdo é representado visualmente.
- **Render** determina como uma imagem aprovada se torna um arquivo raster mestre.
- **Livro** determina tipografia e composição editorial.
- **Pipelines** determina a sequência de execução e os comandos de disparo.
- **Diretivas** determina regras internas de organização e versionamento.
- **Itch** aplica-se somente a materiais produzidos especificamente para itch.io.

---

## Versionamento

Quando um source versionado for alterado:

1. preserve a versão anterior;
2. crie uma nova versão com o número seguinte;
3. use o padrão `Nome.vN.ext`;
4. passe a tratar a versão nova como referência principal.

Exemplo:

```text
Images.v58.txt
Images.v59.txt
```

O `README.md` funciona como ponto de entrada humano. Uma cópia versionada pode ser preservada junto do histórico quando houver atualização relevante.

---

# Pipelines

## Disparo rápido

Um pipeline pode ser iniciado com:

```text
RODE: NOME
```

Exemplo:

```text
RODE: RELÍQUIAS
```

Ao receber o comando, o pipeline consulta automaticamente os sources mais recentes aplicáveis. Não é necessário repetir regras já registradas nos arquivos do projeto.

Formas naturais equivalentes também podem ser aceitas quando o pipeline estiver inequívoco.

---

## Comandos disponíveis

### Produção básica

| Comando | Uso |
|---|---|
| `RODE: RASTER` | PREVIEW de uma imagem → aprovação → FINAL RASTER |
| `RODE: VINHETA` | Ilustração editorial horizontal integrada ao texto |
| `RODE: CENA` | Ilustração narrativa de página inteira |
| `RODE: CARD` | Produção de um CARD individual destinado a uma FOLHA |
| `RODE: FOLHA` | Produção completa de uma FOLHA a partir de cards individuais |
| `RODE: COLEÇÃO` | Sequência de várias FOLHAS de uma mesma categoria |
| `RODE: LOTE` | Produção de duas a dez imagens independentes no mesmo lote |

### Operações

| Comando | Uso |
|---|---|
| `RODE: CORRIGIR` | Refazer ou corrigir somente o card necessário |
| `RODE: MONTAR` | Montar deterministicamente uma FOLHA com cards já aprovados |
| `RODE: FINAL` | Preparar o FINAL RASTER de uma PREVIEW já aprovada |
| `RODE: DIGITAL` | Criar derivado digital a partir do raster mestre |
| `RODE: VERSÃO` | Criar a nova versão necessária de um source alterado |

### Coleções especializadas

| Comando | Coleção |
|---|---|
| `RODE: OCUPAÇÕES` | Ocupações |
| `RODE: CRIATURAS` | Criaturas e ameaças |
| `RODE: RELÍQUIAS` | Relíquias |
| `RODE: PERIGOS` | Perigos Estranhos e do Desconhecido |
| `RODE: NATURAIS` | Perigos naturais e ambientais |
| `RODE: ARMAS` | Armas |
| `RODE: PROTEÇÕES` | Proteções e vestimentas |
| `RODE: SUPRIMENTOS` | Munição, consumíveis, ferramentas e utilitários |
| `RODE: PROVAÇÕES` | Provações comuns e do Desconhecido |
| `RODE: RUMORES` | Rumores e Sinais do Impossível |
| `RODE: LOCAIS` | Postos e locais canônicos |
| `RODE: RELATOS` | Mini-contos e relatos de exploração |

Os pipelines especializados herdam as regras gerais de CARD, FOLHA, COLEÇÃO, PREVIEW e FINAL RASTER, mas usam mapas visuais próprios para o tipo de conteúdo.

---

## Fluxo padrão de uma coleção

Uma coleção visual segue, em termos gerais, esta sequência:

1. consultar a lista canônica nos sources;
2. contar os elementos e fechar a divisão em FOLHAS;
3. fixar cada elemento em uma posição;
4. criar o mapa visual e, quando houver pessoas, o mapa de diversidade;
5. gerar PREVIEWS individuais, preferencialmente em lotes de até dez;
6. apresentar as PREVIEWS reais para aprovação;
7. refazer somente as imagens rejeitadas;
8. preparar o FINAL RASTER individual dos cards aprovados;
9. aplicar os nomes canônicos na etapa editorial, nunca dentro da geração da arte;
10. montar a FOLHA deterministicamente;
11. apresentar a PREVIEW real da montagem;
12. após aprovação, exportar o FINAL RASTER da FOLHA;
13. validar a FOLHA e todos os cards;
14. avançar para a próxima FOLHA até concluir a COLEÇÃO.

Uma mudança localizada não autoriza regenerar cards já aprovados.

---

## Estado visível durante um pipeline

Sempre que um pipeline iniciar, avançar ou parar aguardando uma decisão, deve mostrar onde estamos e o que ainda falta.

Formato de referência:

```text
PIPELINE: RELÍQUIAS
FOLHA: 01/03
CARDS: 8/20
PROGRESSO GERAL: 2/5 etapas

✓ 1. Mapa canônico e visual — concluída
▶ 2. Aprovação das PREVIEWS — ETAPA ATUAL
○ 3. FINAL RASTER dos cards — falta
○ 4. Montagem e nomes da FOLHA — falta
○ 5. Aprovação e FINAL RASTER da FOLHA — falta

DEPOIS:
FOLHA 02 → FOLHA 03 → encerramento da coleção
```

Em qualquer pausa deve ser possível responder rapidamente a três perguntas:

1. Onde estamos?
2. O que já terminou?
3. O que ainda falta para concluir?

---

## Ações rápidas e cancelamento

Quando uma decisão do usuário for necessária, o pipeline deve oferecer ações curtas. Se a interface permitir controles clicáveis, eles devem ser preferidos. Se não permitir, as mesmas opções devem aparecer como comandos curtos.

**CANCELAR deve estar disponível em toda pausa.**

Cancelar:

- interrompe o pipeline atual;
- preserva PREVIEWS, rasters e cards já aprovados;
- não apaga trabalho concluído;
- permite retomada posterior a partir do último estado válido quando os arquivos necessários ainda estiverem disponíveis.

Exemplos de ações:

```text
APROVAR
REFAZER
AJUSTAR
CANCELAR
```

Para lotes:

```text
APROVAR TODAS
REVISAR INDIVIDUALMENTE
REFAZER SELECIONADAS
CANCELAR
```

Para uma FOLHA montada:

```text
APROVAR FOLHA
AJUSTAR MONTAGEM
CORRIGIR CARD
CANCELAR
```

Uma decisão inequívoca deve avançar o pipeline sem uma segunda confirmação redundante.

---

# PREVIEW e FINAL RASTER

## PREVIEW

PREVIEW é a imagem usada para validação visual.

Ela:

- pode estar na resolução nativa da ferramenta;
- não precisa atingir a resolução mestre;
- serve para validar composição, conteúdo, anatomia, atmosfera e coerência;
- **nunca deve ser apresentada como arquivo final**.

Depois da aprovação visual, o pipeline avança para o FINAL RASTER.

## PREVIEW válida

A PREVIEW precisa ser **a própria arte que poderá originar o arquivo final**.

Não contam como PREVIEW válida:

- dashboard;
- infográfico;
- painel de status;
- mockup;
- folha de contato;
- esquema de pipeline;
- screenshot com miniaturas;
- imagem gerada apenas para simular uma FOLHA pronta.

Para CARD, a PREVIEW válida é a ilustração individual real do card.

Para VINHETA e CENA, é a própria ilustração individual.

Para FOLHA, é a montagem determinística real feita a partir dos cards aprovados.

## FINAL RASTER

FINAL RASTER é o arquivo mestre de produção.

Ele:

- só é criado depois da aprovação da PREVIEW correspondente;
- deve preservar conteúdo, composição, personagem, pose, objetos, cenário e enquadramento aprovados;
- deve ser derivado preferencialmente por processamento raster e aumento de resolução controlado;
- não deve reinterpretar generativamente a arte aprovada;
- usa PNG como formato mestre.

Se uma nova geração puder alterar a arte, a saída volta a ser PREVIEW e precisa de nova aprovação.

---

# Lotes de imagens

Quando houver duas ou mais imagens independentes, o padrão é produzir **até dez PREVIEWS por lote**, quando a ferramenta permitir.

Isso significa:

> **Até dez imagens de uma vez = até dez arquivos independentes.**

Nunca significa:

- dez cards dentro da mesma imagem;
- mosaico;
- dashboard;
- folha de contato;
- grid gerado como uma única arte.

Se uma imagem de um lote falhar, somente ela é refeita. As imagens aprovadas permanecem congeladas.

---

# Vocabulário visual canônico

## VINHETA

Uma única ilustração editorial integrada ao fluxo do texto.

- um arquivo independente;
- normalmente horizontal;
- largura de referência igual à largura útil de uma página A4 em retrato;
- não é card nem FOLHA.

## CENA

Uma única ilustração narrativa concebida para página inteira.

- um arquivo independente;
- normalmente vertical;
- maior profundidade ambiental;
- não deve ser transformada em card gigante.

## CARD

Uma ilustração individual que poderá ocupar uma posição de uma FOLHA.

- uma arte por arquivo;
- proporção final **1:2,5**;
- padrão mestre recomendado: **1600 × 4000 pixels**;
- sem texto gerado dentro da arte;
- sem número;
- sem borda, moldura, retângulo, linha de corte ou perímetro desenhado;
- quando houver nome, a área inferior deve preservar espaço branco suficiente para a tipografia editorial posterior.

## FOLHA

Arquivo final contendo até oito cards organizados em **oito posições fixas, quatro colunas por duas linhas**.

Uma FOLHA:

- é montada depois que os cards individuais forem aprovados;
- nunca é criada como uma única geração de inteligência artificial contendo vários cards;
- usa os cards reais aprovados;
- possui gaps e margens brancos;
- mantém posições sem conteúdo completamente vazias quando a última FOLHA possuir menos de oito elementos;
- nunca amplia os cards restantes para preencher posições vazias.

Padrão de montagem atual para uma FOLHA completa:

- card: 1600 × 4000 pixels;
- espaço entre cards: 160 pixels;
- margem externa: 160 pixels;
- FOLHA final: **7200 × 8480 pixels**.

## COLEÇÃO

Conjunto ordenado de várias FOLHAS pertencentes à mesma categoria.

A distribuição é fechada antes da produção. Depois de fixado o mapa, elementos não podem ser adicionados, removidos, repetidos ou reorganizados espontaneamente.

---

# Nomes nos cards

O gerador de imagens **não escreve os nomes dos cards**.

Os nomes são adicionados somente na montagem editorial.

Regras:

- usar somente o nome canônico;
- nunca numerar;
- nunca adicionar índice, código, ordinal, subtítulo ou descrição mecânica;
- usar a tipografia definida por `Livro`;
- manter o nome solto sobre branco;
- não usar placa, caixa, cartela, banner, moldura ou fundo delimitado atrás do nome.

---

# Diversidade em coleções com personagens

Antes da geração de uma FOLHA com pessoas, deve existir um mapa de diversidade visual.

O planejamento considera, conforme aplicável:

- sexo aparente;
- faixa de idade;
- altura e constituição;
- formato do rosto;
- mandíbula e queixo;
- nariz;
- olhos e sobrancelhas;
- maçãs do rosto e testa;
- cabelo e pelos faciais;
- postura;
- direção do corpo;
- ação principal;
- silhueta;
- equipamento dominante;
- ambiente;
- desgaste e expressão.

Mudar somente barba, cabelo, roupa ou chapéu **não conta como diversidade facial**.

Em uma FOLHA completa de oito personagens, quando o conteúdo canônico permitir, o conjunto deve buscar múltiplas faixas de idade, diferentes constituições corporais, variedade de sexo aparente, poses distintas e rostos estruturalmente diferentes.

---

# Direção visual

A fonte detalhada é `Images`.

Resumo:

- somente preto, branco e tons neutros de cinza;
- suporte branco puro;
- branco como parte dominante e ativa da composição;
- gravura histórica de linha limpa;
- hachura mínima e seletiva;
- espaço negativo amplo;
- terror tropical, ameaça, vulnerabilidade, silêncio e mistério;
- evitar aventura heroica, turismo exótico e descoberta triunfante;
- personagens vestidos e não sexualizados;
- pele e tecido comum predominantemente limpos, sem microtextura uniforme;
- floresta tropical inequívoca quando o ambiente exigir, sem transformar o fundo em ruído;
- ornamento como fragmento esparso, nunca como moldura;
- sem bordas ou retângulos em cards;
- sem texto gerado dentro das ilustrações de CARD.

O Desconhecido deve ser sugerido por ausência, vestígio, escala, sombra, reflexo, rastro, ocultação ou fenômeno incompleto sempre que isso preservar melhor a ambiguidade.

---

# Renderização e resolução

A fonte detalhada é `Render`.

## Referência editorial

O padrão central para página inteira é A4 a **400 pixels por polegada**.

A4 retrato:

- aproximadamente **3307 × 4677 pixels**.

A4 paisagem:

- aproximadamente **4677 × 3307 pixels**.

## Regras gerais

- PNG é o arquivo mestre raster;
- fundo branco deve permanecer `#FFFFFF`;
- evitar compressão com perdas no mestre;
- realizar preferencialmente apenas uma etapa de aumento de resolução;
- não engrossar linhas;
- não criar halos;
- não inventar microtextura;
- validar em ampliação de 100 por cento;
- preservar nitidez e espaço branco;
- derivados para PDF, web e distribuição são criados somente depois do mestre.

---

# Tipografia e identidade editorial

A fonte detalhada é `Livro`.

O projeto usa principalmente:

### EB Garamond

Para títulos de livro, capítulos e elementos editoriais solenes.

### Source Serif 4

Para:

- texto corrido;
- subtítulos;
- termos mecânicos;
- nomes de cards;
- legendas;
- notas;
- citações e referência rápida.

O livro, o PDF e o site devem parecer apresentações do mesmo objeto editorial:

- fundo branco;
- texto preto;
- tons neutros de cinza para informação secundária;
- bastante espaço em branco;
- hierarquia clássica;
- ornamentos discretos;
- nenhuma aparência de aplicativo ou dashboard no conteúdo editorial.

---

# Princípios do jogo

## Exploração antes de combate

O foco está em avançar, observar, decidir, negociar, administrar recursos e saber quando recuar. Combate é perigoso e normalmente curto.

## Presença e Bagagem

**Presença** representa quanto desgaste físico e mental um explorador suporta.

**Bagagem** representa sua capacidade limitada de carga. Pertences e Provações disputam os mesmos espaços, fazendo com que ferimentos, doenças e traumas também tenham peso logístico.

## Ação Incerta

Quando uma ação possui resultado incerto e consequência relevante, usa-se uma Ação Incerta com dado de seis lados.

A situação pode ser:

- Normal;
- Favorável;
- Desfavorável.

Vantagens independentes adicionais podem gerar Preparo conforme `Regras`.

## Sempre deve existir escolha

O mundo pode cobrar custos severos, mas o jogo não deve criar bloqueios intencionais sem alternativa.

Falhas podem cobrar:

- tempo;
- Presença;
- Integridade;
- recursos;
- posição;
- informação;
- carga;
- oportunidade.

Quando uma rota fecha, outra escolha, custo, recuo, ajuda ou mudança de abordagem deve continuar possível quando a ficção permitir.

---

# O cenário

A aventura se concentra no interior tropical depois que a expedição perde contato fácil com a costa.

Pressões recorrentes incluem:

- vegetação densa;
- calor e umidade;
- rios e pântanos;
- lama;
- água contaminada;
- fome;
- insetos e parasitas;
- doenças e infecções;
- deterioração de equipamento;
- isolamento;
- medo;
- ambição e ouro;
- distância de Postos Avançados.

O ambiente deve ser tão ameaçador quanto qualquer inimigo.

## O Desconhecido

O Desconhecido é:

- raro;
- incompreendido;
- ambíguo;
- perigoso quando alguém tenta forçá-lo ou compreendê-lo.

Relíquias e fenômenos inexplicáveis não funcionam como magia previsível. Uma mesma experiência pode receber explicações naturais, psicológicas, religiosas, fraudulentas ou permanecer sem explicação.

---

# Relatos de exploração

`Relatos` reúne mini-contos que podem ser usados:

- entre capítulos;
- antes de uma sessão;
- durante viagens;
- como fragmentos encontrados pela expedição;
- como fonte para CENAS, FOLHAS e atmosfera.

Nem tudo narrado neles precisa ser verdadeiro dentro do mundo.

O pipeline `RODE: RELATOS` transforma cada relato em um elemento visual independente, escolhendo um único instante narrativo forte sem tentar condensar todo o conto em uma imagem.

---

# Publicação

O projeto está sendo preparado para:

- livro físico;
- PDF digital;
- página web em formato de livro corrido.

Uma organização editorial possível é:

1. capa;
2. abertura e cenário;
3. regras essenciais;
4. Ocupações e opções dos exploradores;
5. equipamentos e sobrevivência;
6. perigos, criaturas e ameaças;
7. Desconhecido e Relíquias;
8. Relatos distribuídos entre capítulos;
9. Guia do Mestre;
10. Referência Rápida;
11. créditos e licença;
12. fechamento.

## itch.io

As exigências de `Itch` só se aplicam a arquivos preparados especificamente para itch.io.

Na versão vigente, imagens para itch.io devem:

- ser PNG;
- ter menos de 2,9 megabytes;
- para cover, usar no mínimo 315 × 250 pixels e preferencialmente 630 × 500 pixels.

Esses derivados não substituem os masters de produção.

---

# Licença

**Autor:** Fellipe Augusto Ugliara

O material do projeto indica licença:

**Creative Commons Atribuição–NãoComercial–CompartilhaIgual.**

Em resumo:

- é permitido compartilhar;
- é permitido adaptar;
- o autor deve receber crédito;
- o material não deve ser usado para fins comerciais;
- adaptações devem manter licença compatível com CompartilhaIgual.

Consulte os sources antes da publicação para confirmar o texto completo de licença e os créditos finais.

---

# Regra de ouro do projeto

> **O Inferno Verde deve ser simples de jogar, difícil de atravessar e sempre oferecer uma escolha.**

A selva consome recursos. A Bagagem nunca parece suficiente. Equipamentos quebram. Corpos e mentes acumulam marcas. O ouro pode valer menos que água limpa. O Desconhecido nunca precisa explicar a si mesmo.

O objetivo não é vencer a floresta. É decidir quanto ainda vale a pena carregar para continuar avançando.

## Interação durante pipelines

O estado do pipeline é sempre mostrado como texto na conversa, nunca como dashboard, infográfico, mockup ou imagem de status. Imagens geradas durante um pipeline devem ser somente arte real do projeto, como CARD, VINHETA ou CENA.

### Pipeline ativo

Um pipeline fica **ATIVO** desde o momento em que um comando `RODE:` é disparado até sua conclusão, cancelamento ou interrupção explícita.

**Enquanto estiver ATIVO, toda resposta relacionada ao pipeline deve terminar com o bloco de continuidade. Isso é obrigatório.** O usuário nunca deve precisar procurar mensagens anteriores para descobrir onde o processo está.

O bloco final de cada resposta mostra:

- nome do pipeline;
- Folha atual/total, quando aplicável;
- progresso mensurável;
- etapa atual destacada;
- etapas concluídas;
- todas as etapas que ainda faltam até o final;
- estado do resultado que acabou de ser produzido;
- ações disponíveis naquele momento;
- `CANCELAR` sempre disponível enquanto o pipeline continuar ativo.

Exemplo:

```text
PIPELINE: RELÍQUIAS — ATIVO
FOLHA: 01/03
PROGRESSO: 8/20 cards

✓ 1. Mapa canônico — concluído
▶ 2. Aprovação das PREVIEWS — ETAPA ATUAL
○ 3. FINAL RASTER dos cards — falta
○ 4. Montagem da Folha — falta
○ 5. Aprovação + FINAL RASTER da Folha — falta
○ 6. Folhas 02 e 03 — faltam
○ 7. Encerrar coleção — falta

ESTADO: aguardando decisão.
AÇÕES: APROVAR TODAS · REVISAR · REFAZER · CANCELAR
```

Se nenhuma decisão do usuário for necessária naquele momento, o bloco informa **AÇÃO DO USUÁRIO: nenhuma necessária** e mostra qual será a próxima etapa automática, sem criar uma confirmação artificial.

Se uma geração for inválida, a etapa permanece não concluída, o progresso volta ao último estado válido e o bloco continua obrigatório, indicando a ação corretiva disponível.

Quando a interface disponibilizar botões ou chips reais para escolhas arbitrárias, eles devem ser usados. Quando esse suporte não estiver disponível, as mesmas ações aparecem como respostas curtas na própria conversa, por exemplo: `APROVAR TODAS · REVISAR · REFAZER · CANCELAR`. Nunca desenhar ou simular botões dentro de uma imagem.

Ao concluir ou cancelar, o último bloco mostra `ESTADO: CONCLUÍDO` ou `ESTADO: CANCELADO`. A obrigação termina somente então.

