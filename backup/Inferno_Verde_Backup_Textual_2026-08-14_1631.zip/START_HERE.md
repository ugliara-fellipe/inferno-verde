# O Inferno Verde — Backup textual

Backup textual do projeto **O Inferno Verde: O Preço da Expedição**.

Criado em: 14 de agosto de 2026, 16:31 (America/Sao_Paulo)

## Estado
- Nenhum pipeline ativo.
- Nenhuma arte faz parte deste backup.
- Este pacote contém somente sources canônicos atuais e documentação textual complementar.

## Ordem recomendada de leitura
1. `Diretivas.v2.txt`
2. `Regras.v29.txt`
3. `Cenario.v12.txt`
4. `Relatos.v7.txt`
5. `Images.v71.txt`
6. `Render.v12.txt`
7. `Pipelines.v31.txt`
8. `Livro.v3.txt`
9. `Itch.v2.txt`
10. `README.v27.md`
11. `LICENSE.v1.txt`

## Versionamento
Sempre use a maior versão disponível de cada source.
Quando um arquivo precisar ser alterado, crie uma nova versão em vez de sobrescrever a anterior.
