# O Inferno Verde — backup textual

Este pacote contém somente arquivos de texto necessários para preservar e retomar o projeto.

Não contém:
- artes;
- PNGs;
- rasters;
- previews;
- cards renderizados;
- arquivos de fonte;
- ZIPs de imagens.

## Ordem recomendada de leitura

1. `01_SOURCES_CANONICOS/Diretivas.v2.txt`
2. `02_DOCUMENTACAO_COMPLEMENTAR/README.v20.md`
3. `01_SOURCES_CANONICOS/Regras.v29.txt`
4. `01_SOURCES_CANONICOS/Cenario.v12.txt`
5. `01_SOURCES_CANONICOS/Relatos.v7.txt`
6. `01_SOURCES_CANONICOS/Images.v70.txt`
7. `01_SOURCES_CANONICOS/Render.v12.txt`
8. `01_SOURCES_CANONICOS/Pipelines.v21.txt`
9. `01_SOURCES_CANONICOS/Livro.v3.txt`
10. `01_SOURCES_CANONICOS/Itch.v2.txt`

## Regra de versões

Use sempre a maior versão disponível de cada família de arquivo.

Ao alterar um source, crie uma nova versão em vez de sobrescrever a atual.

## Estado no momento deste backup

Nenhum pipeline está ativo.

Este backup foi criado em 14 de agosto de 2026, 13:52, America/Sao_Paulo.
