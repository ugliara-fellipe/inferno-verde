# O Inferno Verde — backup local

Snapshot criado em: 14 de agosto de 2026, 12:21 (America/Sao_Paulo)

## Por onde começar

Leia nesta ordem:

1. `01_SOURCES_CANONICOS/Diretivas.v2.txt`
2. `01_SOURCES_CANONICOS/README.v14.md`
3. `01_SOURCES_CANONICOS/Pipelines.v18.txt`
4. `01_SOURCES_CANONICOS/Images.v67.txt`
5. `01_SOURCES_CANONICOS/Render.v10.txt`
6. `01_SOURCES_CANONICOS/Livro.v3.txt`

## Sources canônicos deste snapshot

- Diretivas.v2.txt
- Itch.v2.txt
- Livro.v3.txt
- Cenario.v12.txt
- Relatos.v7.txt
- Regras.v29.txt
- Images.v67.txt
- Render.v10.txt
- Pipelines.v18.txt
- README.v14.md

Somente as maiores versões atuais de cada família foram incluídas como sources canônicos.

## Estado dos trabalhos visuais

### Vinheta — Quando a Selva Respira
Concluída e aprovada:
- PREVIEW aprovada preservada;
- FINAL RASTER 3307 px / 400 PPI;
- validação preservada.

### Relíquias — iteração anterior
Folha 01 concluída e aprovada:
- 8 cards;
- 8 cards nomeados;
- montagem;
- FINAL RASTER da Folha 01;
- PREVIEW e montagem de aprovação;
- validação.

### Relíquias — iteração v2 mais recente
A nova Folha 01 foi:
- gerada com direção visual atualizada;
- ajustada para menor densidade;
- aprovada;
- transformada em 8 FINAL RASTER individuais;
- CANCELADA antes da aplicação dos nomes.

Esse trabalho parcial está em:
`03_TRABALHO_PARCIAL_PRESERVADO/Reliquias_Folha01_iteracao_v2_cancelada_antes_dos_nomes/`

Ele deve ser tratado como a iteração visual mais recente caso você queira retomá-la.

### Ocupações
O arquivo existente `Prancha_Ocupacoes_01_final_400ppi.png` foi preservado, mas não foi revalidado nesta etapa de backup.

## Tipografia atual

Tipografia canônica:
- Noto Serif: corpo, termos, labels e nomes de cards.
- Noto Serif SemiBold: nomes de cards.
- EB Garamond: títulos editoriais e capítulos.

Arquivos de fonte NÃO são incluídos no backup.

## Continuação segura

Ao alterar qualquer source:
- nunca sobrescrever a versão atual;
- criar uma nova versão;
- usar sempre a maior versão como canônica.

O arquivo `CHECKSUMS.sha256` permite conferir integridade do backup.
